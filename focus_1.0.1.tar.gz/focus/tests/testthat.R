library(testthat)
library(focus)

test_check("focus")
